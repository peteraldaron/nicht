#pragma once

#include <string>
using std::string;

enum nmf_init_params {
    RANDOM,
    NNDSVD,
    NNDSVDA,
    NNDSVDAR,
    CUSTOM
};

template <typename MatrixT>
void non_negative_factorization(const MatrixT &X, enum nmf_init_params init, const bool update_H = true,
                                const string &solver="cd", const string &beta_loss="frobenius", const double tol=1e-4,
                                const size_t max_iter=200, const double alpha=0, const double l1_ratio=0)
{
    const auto &[n_sample, n_features] = X.shape;
}
