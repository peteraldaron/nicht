import yasp
import scipy.sparse as sp
import numpy as np

a = sp.csr_matrix(np.arange(32).reshape((4, 8)))
csr = yasp.csr_matrix(a.indptr, a.indices, a.data, 4, 8, 32)
yasp._verify(csr)
