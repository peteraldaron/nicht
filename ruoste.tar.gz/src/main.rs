extern crate flate2;

use std::string::String;
use std::io::prelude::*;
use flate2::read::GzDecoder;
mod s3;

enum POS {
    PLUSSA_CARDNUMBER,
    CUSTCONTACT_ID,
    PERSON_ID,
    HOUSEHOLD_ID,
    EAN_CODE,
    PRODUCT_NAME,
    PRODUCTHIERARCHYLEVEL1,
    PRODUCTHIERARCHYLEVEL1NAME,
    PRODUCTHIERARCHYLEVEL2,
    PRODUCTHIERARCHYLEVEL2NAME,
    PRODUCTHIERARCHYLEVEL3,
    PRODUCTHIERARCHYLEVEL3NAME,
    PRODUCTHIERARCHYLEVEL4,
    PRODUCTHIERARCHYLEVEL4NAME,
    PRODUCTHIERARCHYLEVEL5,
    PRODUCTHIERARCHYLEVEL5NAME,
    SALES_PRICE,
    VAT_AMOUNT,
    SALES_QUANTITY,
    RECEIPT_DATE,
    SITE_ID,
    SOURCEBUSINESSUNIT_ID,
    CUSTCHAIN_ID,
    CHAINUNIT_ID,
    RECEIPT_ID,
    FOOD_NONFOOD_IND,
    CUST_TYPE_CD,
    TRANSACTION_GROSS_AMT_EUR,
    PROFIT_AMT_EUR,
    LOSS_AMT_EUR
}

// kesko-aws-data-import/pdata/KEDW_AWS_POS_DTL_201'

fn read_csv_file(file_text: &Vec<u8>) -> String {
    let file_bytes: &[u8] = &file_text;
    let mut content = String::new();
    let mut decode = GzDecoder::new(file_bytes);
    decode.read_to_string(&mut content).unwrap();
    return content;
}

fn main() {
    let pos = s3::get_object("kesko-aws-data-import",
                             "pdata/KEDW_AWS_POS_DTL_20181010_8.txt.gz");
    let result = read_csv_file(&pos);
    for line in result.lines() {
        let tokens: Vec<&str> = line.split("|").collect();
        println!("{}", tokens[0]);
    }
}
