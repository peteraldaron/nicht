extern crate rusoto_core;
extern crate rusoto_s3;
extern crate futures;

use self::futures::{Future, Stream};
use self::rusoto_core::Region;
use self::rusoto_s3::{S3Client, GetObjectRequest, S3, StreamingBody};

use std::collections::HashMap;
use std::env;
use std::fs::File;
use std::io::Read;

// from https://github.com/rusoto/rusoto/blob/master/integration_tests/tests/s3.rs
pub fn get_object(bucket: &str, filename: &str) -> Vec<u8> {
    let client = S3Client::new(Region::EuWest1);
    let get_req = GetObjectRequest {
        bucket: bucket.to_string(),
        key: filename.to_string(),
        ..Default::default()
    };

    let result = client.get_object(get_req).sync().expect("Couldn't GET object");
    println!("get object result: {:#?}", result);

    let stream = result.body.unwrap();
    let body = stream.concat2().wait().unwrap();
    return body;
}
